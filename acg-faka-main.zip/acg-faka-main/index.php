<?php
declare(strict_types=1);

/**
 * 开启DEBUG
 */
const DEBUG = false;
require("kernel/Kernel.php");